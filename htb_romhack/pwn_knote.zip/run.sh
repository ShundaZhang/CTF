#!/bin/bash

qemu-system-x86_64 \
    -m 128M \
    -nographic \
    -kernel ./bzImage \
    -append 'console=ttyS0 quiet kaslr' \
    -monitor /dev/null \
    -initrd ./initramfz \
    -cpu kvm64,+smep,+smap
