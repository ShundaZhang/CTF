# personal-website

This is my personal website where I will share my vacation photos and favorite memes!

It's WIP! Stay tuned!

## Dependencies
I am using HTML5 Boilerplate and generate this format with the tool [create-html5-boilderplate](https://github.com/h5bp/create-html5-boilerplate).
* npm is used to run the site

## How to run
1. Clone this repo - `git clone git@github.com:tc-trooper17254/personal-website.git`
2. Install node packages - `npm install`
3. Add privates_files!
4. Start site - `npm start`

## Todo
* CSS!
* Figure out Apache

- tc-trooper17254


