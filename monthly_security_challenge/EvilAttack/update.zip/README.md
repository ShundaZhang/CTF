## Evil Attack Challenge Q&A (v1.0)

Q. Will this README help me solve the challenge?
A. Nope. ¯\_(ツ)_/¯

Q. Can I DoS attack the web server?
A. Please don't.

Q. My "update.zip" successfully passes the run_local_test(), but your server rejects it.
A. umm... please contact me.

Q. Can I somehow hack the Web server without uploading the "update.zip" file?
A. I hope not. see the next question...

Q. I think there is a real security issue unrelated to the challenge, what should I do?
A. I will appreciate it if you could report it to me ASAP.

Q. I've solved the challenge. Besides getting the flag, can I look around or mess things up?
A. Please don't. If you are interested in the website setup, feel free to contact me.

Q. I think my solution is different than the expected one.
A. Interesting! I will be happy to know how you did it.

If you have any other questions, feedback, or suggestions for improvement, please feel free to contact me.

Good luck
tal.rosen@intel.com
===============================================================================================================
   Special thanks go to:
   Zeltser, Benny; Duda, Przemyslaw; Sudai, Rami; SFIP-PSTE-VEST-SECEV (SecWiz); Moore, Donna; Barkai, Aviv
===============================================================================================================