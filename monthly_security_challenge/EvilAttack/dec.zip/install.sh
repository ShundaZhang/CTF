bash -c "$(base64 -d <<< "\
ZWNobyAkZmxhZwo=")" bash "$@"
# 🤔
# env | grep flag
